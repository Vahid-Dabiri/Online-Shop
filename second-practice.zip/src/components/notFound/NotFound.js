import React from 'react'
import './NotFound.css'

export default function NotFound() {
  return (
    <div>404 NotFound</div>
  )
}
