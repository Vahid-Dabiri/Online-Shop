const categories = [
    {
        title: "men's clothing", 
        image: './images/0001.jpg'
    },
    {
        title: "women's clothing", 
        image: './images/0002.jpg'
    },
    {
        title: "electronics", 
        image: './images/0003.jpg'
    },
    {
        title: "jewelery", 
        image: './images/0004.jpg'
    }
];

const counters = [
    {
        title: 'Title 1',
        counter: 120
    },
    {
        title: 'Title 2',
        counter: 3000
    },
    {
        title: 'Title 3',
        counter: 24
    },
    {
        title: 'Title 4',
        counter: 50
    },
]

export {categories, counters}